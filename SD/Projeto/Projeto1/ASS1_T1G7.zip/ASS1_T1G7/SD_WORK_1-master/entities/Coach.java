package entities;

import comumInfra.*;
import main.SimulPar;
import sharedRegions.*;

public class Coach extends Thread {

    /**
     * Coach state.
     */
    private int coachState;

    /**
     * Coach team.
     */
    private int teamId;

    /**
     * Reference to the play ground.
     */

    private PlayGround plGrnd;

    /**
     * Reference to the Refree Site.
     */

    private Refree_site site;

    /**
     * Reference to the Contestant bench.
     */

    private Contestants_bench bench;

    Start stratagy;

    Contestant[] p = new Contestant[5];

    /**
     * Instantiation of a barber thread.
     *
     * @param name       thread name
     * @param teamId     coach´s team (will also be used as Coach Id)
     * @param site       reference to the refree site
     * @param playGround reference to the play groun
     * @param bench      reference to the contestants's bench
     */

    public Coach(String name, int teamId, Refree_site site, PlayGround playGround, Contestants_bench bench) {

        // this.stratagy = new Start(p, stratagy);

        // this.p = p;
        super(name);
        this.teamId = teamId;
        this.site = site;
        this.bench = bench;
        this.plGrnd = playGround;
        coachState = CoachStates.WAITFORREFEREECOMMAND;

    }

    /**
     * Set Coach state.
     *
     * @param state new Coach state
     */

    public void setCoachState(int state) {
        coachState = state;
    }

    /**
     * Set Coach Team Id.
     *
     * @param teamId new Refree state
     */

    public void setCoachTeamId(int teamId) {
        this.teamId = teamId;
    }

    /**
     * Set new Reference to the contestant bench.
     *
     * @param bench Contestant Strength
     */

    public void setContestantBench(Contestants_bench bench) {
        this.bench = bench;
    }

    /**
     * Get Coach state.
     *
     * @return Coach state
     */

    public int getCoachState() {
        return coachState;
    }

    /**
     * Get Coach team Id.
     *
     * @return TeamId
     */

    public int getCoachTeamId() {
        return teamId;
    }

    /*
     * public void start_team() {
     * 
     * for (int i = 0; i < 5; i++)
     * p[i].start();
     * 
     * }
     */

    /*
     * public void join_team() {
     * 
     * for (int i = 0; i < 5; i++) {
     * try {
     * p[i].join();
     * } catch (InterruptedException e) {
     * }
     * }
     * 
     * }
     */
    @Override
    public void run() {

        // int customerId; // customer id
        // boolean endOp; // flag signaling end of operations
        boolean endOfMatch = false;

        while (!endOfMatch) {
            bench.callContestants();
            site.infomeRefree();
            bench.reviewNotes();
            endOfMatch = plGrnd.getEndOfMatch();
            /*
             * endOp = site.goToSleep_Coach(); // the barber sleeps while waiting for a
             * customer to service
             * if (endOp)
             * break; // check for end of operations
             * 
             * this.p = bench.callContestants(this.stratagy, this.p); // the barber has
             * waken up and calls next customer
             * 
             * 
             * // whait for trial conclusion (Professor email) and get reviweNotes
             */
        }

    }

    private void sleep()
   {
      try
      { sleep ((long) (1 + 100 * Math.random ()));
      }
      catch (InterruptedException e) {}
   }

}