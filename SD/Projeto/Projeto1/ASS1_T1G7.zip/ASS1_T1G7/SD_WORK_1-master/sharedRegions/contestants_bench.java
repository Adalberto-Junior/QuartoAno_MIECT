package sharedRegions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import comumInfra.*;
import entities.*;
import main.*;

/**
 * Contestant Bench.
 *
 * It is responsible to simulate the contestant's bench
 * and is implemented as an implicit monitor.
 * All public methods are executed in mutual exclusion.
 * 
 * 
 */
public class Contestants_bench {

    /**
     * Reference to the general repository.
     */

    private final GeneralRepos repos;

    /**
     * Reference to the play ground.
     */

    private final PlayGround plGrnd;
    /**
     * Array of Contestant.
     */
    private Contestant[][] allCont;

    /**
     * Array with the contestant's selected to play
     */
    private int[][] player;

    /**
     * Array with the contestant's selected to play in last trial
     */
    private int[][] played;

    /**
     * Array with the strength of the contestant who was selected to play
     */
    private int[][] strength;

    /**
     * variable that wakes up the coach after the callContestants()
     */
    private boolean followCoachAdv;

    /*
     * variable that wakes up the coach after the callTrial
     */
    private boolean callTrial;

    /*
     * variable that wakes up the contestant after the startTrial
     */
    private boolean startTrial;

    /*
     * variable that wakes up the contestant after the callContestants
     */
    private boolean callContestant;

    /*
     * Contestant's number playing
     */
    private int nContPlaying;

    /*
     * Total Coach's number
     */
    private int ntotalCoach;

     /*
     * TODO
     */
    private boolean notFistrMatch;

    private boolean team1Comp;

    private boolean team2Comp;


    // Contestant[] p = new Contestant[5];

    /**
     * Contestant bench instantiation.
     *
     * @param repos      reference to the general repository
     * @param playGround reference to the play groun
     */

    public Contestants_bench(GeneralRepos repos, PlayGround playGround) {
        this.repos = repos;
        plGrnd = playGround;
        followCoachAdv = false;
        startTrial = false;
        callTrial = false;
        callContestant = false;
        notFistrMatch = false;
        team1Comp = false;
        team2Comp = false;
        nContPlaying = 0;
        ntotalCoach = 0;
        allCont = new Contestant[SimulPar.N][SimulPar.M];
        player = new int[SimulPar.N][SimulPar.M - 2];
        for (int i = 0; i < SimulPar.N; i++) {
            for (int k = 0; k < (SimulPar.M - 2); k++) {
                player[i][k] = 0;
            }
        }
        played = new int[SimulPar.N][SimulPar.M - 2];
        for (int i = 0; i < SimulPar.N; i++) {
            for (int k = 0; k < (SimulPar.M - 2); k++) {
                played[i][k] = 0;
            }
        }
        strength = new int[SimulPar.N][SimulPar.M - 2];
        for (int i = 0; i < SimulPar.N; i++) {
            for (int k = 0; k < (SimulPar.M - 2); k++) {
                strength[i][k] = 0;
            }
        }

    }

    /**
     * Operation setContestant.
     *
     * is an auxiliary method that we created to update the allCont variable
     * 
     * 
     */
    public synchronized void setContestant(Contestant[][] cont) {
        allCont = cont;
    }

    /**
     * Operation call Contestants.
     *
     * It is called by the coaches when they want to select the Contestant for the
     * next trial.
     * 
     */
    public synchronized void callContestants() {
        Coach coach = (Coach) Thread.currentThread();
        coach.setCoachState(CoachStates.ASSEMBLETEAM);
        int coachTeamID = coach.getCoachTeamId();
        int coachState = coach.getCoachState();
        repos.setCoachState(coachTeamID, coachState);
        team1Comp = true;
        team2Comp = true;
        notifyAll();

        if (coachTeamID == 0) {
            // Strategy of the strongest
            List<Contestant> contest = new LinkedList<Contestant>(Arrays.asList(allCont[0]));
            //System.out.println(contest);
            int sel = 0;
            int nCont = SimulPar.M;
            int k_ = 0;
            while (sel < 3) {
                int i_ = -1;
                int sg = 0;
                int sgTemp1, sgTemp2 = 0;
                for (int i = 0; i < nCont - 1; i++) {
                    sgTemp1 = contest.get(i).getContestantSG();
                  //  System.out.println("SGT1: "+sgTemp1);
                    sgTemp2 = contest.get(i + 1).getContestantSG();
                  //  System.out.println("SGT2: "+sgTemp2);
                    if (sgTemp1 <= sgTemp2) {
                        if (sg < sgTemp2) {
                            sg = sgTemp2;
                            i_ = i + 1;
                        }
                    } else {
                        if (sg < sgTemp1) {
                            sg = sgTemp1;
                            i_ = i;
                        }
                    }
                }
                player[0][k_] = contest.get(i_).getContestantID();
               // System.out.println("Player[0][k_]: "+ player[0][k_]);
                strength[0][k_] = contest.get(i_).getContestantSG();
                contest.remove(i_);
                nCont--;
                k_++;
                sel++;
            }
        } else {
            // Strategy take anyone (Random)
            Random random = new Random();
            ArrayList<Integer> invalid = new ArrayList<Integer>(); // Already selected
            for (int i = 0; i < (SimulPar.M - 2); i++) {
                boolean valid = false;

                while (!valid) {
                    int randomNumber = random.nextInt(5);
                    if (!invalid.contains(randomNumber)) {
                        player[1][i] = randomNumber;
                        //System.out.println("Player[1][i]: "+player[1][i] );
                        valid = true;
                        invalid.add(randomNumber);
                    }
                }

            }
        }
        List<Contestant> cont = Arrays.asList(allCont[1]);
       // System.out.println("contList: " + cont);
        for (int i = 0; i < player[1].length; i++) {
         //   System.out.println("IP: "+ i);
           // System.out.println("Player: " + player[1][i]);
            //System.out.println("StregnI: : "+ cont.get(player[1][i]).getContestantSG());
            strength[1][i] = cont.get(player[1][i]).getContestantSG();
        }

        plGrnd.setStrength(strength);
        ntotalCoach++;
        if (ntotalCoach == 2) {
            callContestant = true;
            //System.out.println("ntotalCoach: " + ntotalCoach);
            ntotalCoach = 0;
            notifyAll();
            
        }
        /*
        for(int j = 0; j < SimulPar.N; j++){
            for(int i = 0; i < SimulPar.M-2;i++){
                for(int k = 0; k < SimulPar.M-2;k++){
                    if(played[j][i] != player[j][k]){
                        if(j == 0){
                            for(int i_ = 0; i_ < SimulPar.M-2; i_++){
                                if(allCont[0][i_].getContestantID() == played[j][i])
                                    allCont[0][i_].setContestantSG(allCont[0][i_].getContestantSG()+1);
                            }
                        }else{
                            for(int i_ = 0; i_ < SimulPar.M-2; i_++){
                                if(allCont[1][i_].getContestantID() == played[j][i])
                                    allCont[1][i_].setContestantSG(allCont[1][i_].getContestantSG()+1);
                            }
                        } 
                    }
                }
            }
        }
        */
        
        while (!followCoachAdv) {
            try {
                System.out.println("Block: " + followCoachAdv);
                wait();
            } catch (InterruptedException e) {
            }
        }
        
    }

    /**
     * Operation Review Notes.
     *
     * It is called by the coaches when they review the Notes of the trial.
     *
     * 
     */
    public synchronized void reviewNotes() {
        Coach coach = (Coach) Thread.currentThread();
        coach.setCoachState(CoachStates.WAITFORREFEREECOMMAND);
        int coachTeamID = coach.getCoachTeamId();
        int coachState = coach.getCoachState();
        repos.setCoachState(coachTeamID, coachState);
        played = player;
        while (!callTrial) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * Operation wakeUpCoach.
     *
     * It is called by the refree when he make callTrial.
     *
     */
    public synchronized void wakeUpCoach() {
        callTrial = true;
        notifyAll();
    }

    /**
     * Operation Follow Call Advice.
     *
     * It is called by the contestant if he was selected to play.
     *
     * 
     */
    public synchronized void followCoachAdvice() {
        Contestant contestant = (Contestant) Thread.currentThread();
        int contID = contestant.getContestantID();
        int contTeamId = contestant.getContestantTeamId();
        int newSG = contestant.getContestantSG();
        repos.setContestantStrength(contTeamId, contID, newSG);
        boolean selected = false;
        int position = 0;
        boolean imPlaying = false;
        //System.out.println("ID: "+ contID);
        

        

        if (contTeamId == 0) {
            while ((player[contTeamId][0] == player[contTeamId][1]) && (player[contTeamId][0] == player[contTeamId][2]) && (player[contTeamId][1] == player[contTeamId][2])) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
            if((player[0][0] != player[0][1]) && (player[0][0] != player[0][2]) && (player[0][1] != player[0][2])){
                //System.out.println("Chegueiiiiii: ");
                for (int i = 0; i < (SimulPar.M - 2); i++) {
                   // System.out.println("player[0][i]: " + player[0][i]);
                    if (contID == player[0][i]) {
                        selected = true;
                        position = i;
                       // System.out.println("Comtest1: " + player[0][i]);
                    }
                }
            }

        } else {
            while ((player[contTeamId][0] == player[contTeamId][1]) && (player[contTeamId][0] == player[contTeamId][2]) && (player[contTeamId][1] == player[contTeamId][2])) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
            if((player[1][0] != player[1][1]) && (player[1][0] != player[1][2]) && (player[1][1] != player[1][2])){
                for (int i = 0; i < (SimulPar.M - 2); i++) {
                   // System.out.println("player[1][i]: " + player[1][i]);
                    if (contID == player[1][i]) {
                        selected = true;
                        position = i;
                       // System.out.println("Comtest2: " + player[1][i]);
                    }
                }
            }
        }
        if((player[0][0] == player[0][1]) && (player[0][0] == player[0][2]) && (player[0][1] == player[0][2]) && team1Comp){
            System.out.println("1 completou");
            team1Comp = false;
            notifyAll();
        }

        if((player[1][0] == player[1][1]) && (player[1][0] == player[1][2]) && (player[1][1] == player[1][2]) && team2Comp){
            System.out.println("2 completou");
            team2Comp = false;
            notifyAll();
        }
        if (selected) {
            contestant.setContestantState(ContestantStates.STANDINPOSITION);
            int stateCont = contestant.getContestantState();
            repos.setContestantState(contTeamId, contID, stateCont);
            repos.setContestantTrialId(contTeamId, contID, position);
            imPlaying = true;
            nContPlaying++;
            //System.out.println("Contestan: "+ contID + "Team: " + contTeamId);
        }else{
            contestant.addStreangth();
        }
        
       

        //System.out.println("NcontP: "+ nContPlaying);
        
        if (nContPlaying == 6) {
            followCoachAdv = true;
            notifyAll();
        }

       


        while (!startTrial) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
        notFistrMatch = true;
        System.out.println("RUIIIIIIIIIIIIIIII");
    }

    /**
     * Operation wakeUpContestant.
     *
     * It is called by the refree when he start the new trial.
     *
     * 
     */
    public synchronized void wakeUpContestant() {
        startTrial = true;
        //System.out.println("StartTrial: "+ startTrial);
        notifyAll();
    }

    /**
     * Operation Seat Down.
     *
     * It is called by the contestants When they finish the trial
     * and go to bench
     */

    public synchronized void seatDown() {
        Contestant contestant = (Contestant) Thread.currentThread();
        int ContID = contestant.getContestantID();
        int stateCont = contestant.getContestantState();
        int contTeamId = contestant.getContestantTeamId();

        if (stateCont == ContestantStates.DOYOURBEST) {
            contestant.setContestantState(ContestantStates.SEATATTHEBENCH);
            int newstateCont = contestant.getContestantState();
            repos.setContestantState(contTeamId, ContID, newstateCont);
           /*
            if(contTeamId == 0){
                for(int i = 0; i < SimulPar.M-2; i++){
                    if(allCont[0][i].getContestantID() == ContID)
                        allCont[0][i].setContestantSG(allCont[0][i].getContestantSG()-1);
                }
            }else{
                for(int i = 0; i < SimulPar.M-2; i++){
                    if(allCont[1][i].getContestantID() == ContID)
                        allCont[1][i].setContestantSG(allCont[1][i].getContestantSG()-1);
                }
            }*/

            while (!callContestant) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
        }
    }


    /*
    public synchronized void setContestants() {
        Contestant contestant = (Contestant) Thread.currentThread();
        int ContID = contestant.getContestantID();
        int contTeamId = contestant.getContestantTeamId();
        if(contTeamId == 0){
            allCont[0][j] = contestant;
            j++;
        }else{
            allCont[0][j_] = contestant;
            j_++;
        }
        if(j > 5 && j_ > 5){
            full = true;
        }
    }

    public synchronized boolean isFull(){
        return full;
    }
    */

}
