package main;

import entities.*;
import sharedRegions.*;
import genclass.GenericIO;
import genclass.FileOp;

import java.util.Random;

/**
 * Simulation of the Game of the Rope.
 * Static solution based on a posteriori reasoning to terminate the barbers
 * threads.
 */

public class GameOfTheRope {

    /**
     * Main method.
     *
     * @param args runtime arguments
     */

    public static void main(String[] args) {

        GeneralRepos repos;                                  // reference to the general repository
        Refree_site site;                                     // reference to the Refree site 
        PlayGround plGrnd;                                    // reference to the Play Ground
        Contestants_bench bench;                              //  reference to the Contestant Bench
        String fileName;                                     // logging file name
        char opt;                                            // selected option
        boolean success;                                     // end of operation flag
         /* problem initialization */

      GenericIO.writelnString ("\n" + "\t\t\t\t\t\tGame of the Rope\n");
      do
      { GenericIO.writeString ("Logging file name? ");
        fileName = GenericIO.readlnString ();
        if (FileOp.exists (".", fileName))
           { do
             { GenericIO.writeString ("There is already a file with this name. Delete it (y - yes; n - no)? ");
               opt = GenericIO.readlnChar ();
             } while ((opt != 'y') && (opt != 'n'));
             if (opt == 'y')
                success = true;
                else success = false;
           }
           else success = true;
      } while (!success);


        repos = new GeneralRepos(fileName); 
        plGrnd = new PlayGround(repos);
        bench = new Contestants_bench(repos,plGrnd);
        site = new Refree_site(repos,bench,plGrnd);
        Refree refree = new Refree("Refree", site, plGrnd,bench);
        Random random = new Random();
        Contestant[][] contestants = new Contestant[SimulPar.N][SimulPar.M];
        Coach[] coach = new Coach[2];



        for (int i = 0; i < SimulPar.N; i++) {
            for(int k = 0; k < SimulPar.M; k++){
                int randomNumber = 0;
                do {
                    randomNumber = random.nextInt(11);   
                } while (randomNumber < 6);
                contestants[i][k] = new Contestant("Cont_" + (k+1), (k),(i),randomNumber,bench,plGrnd);
            }
            coach[i] = new Coach("Coa_" + (i+1),(i), site, plGrnd, bench);  
        }

        bench.setContestant(contestants);
        
    
        
        for(int i = 0; i < SimulPar.N; i++){
            for(int k = 0; k < SimulPar.M; k++){
                contestants[i][k].start();
            }
        }
        for (int i = 0; i < SimulPar.N; i++) {
            coach[i].start();
        }
        
        refree.start();
        GenericIO.writelnString();
        for (int i = 0; i < SimulPar.N; i++) {
            for(int k = 0; k < SimulPar.M; k++){
                try {
                    contestants[i][k].join();
                } catch (InterruptedException e) {
                }
                GenericIO.writelnString("The contestant " + (i + 1) +" " + (k+1) + " has terminated.");
                
            }
        }
        GenericIO.writelnString();

        //GenericIO.writelnString();
        for (int i = 0; i < SimulPar.N; i++) {
            try {
                coach[i].join();
            } catch (InterruptedException e) {
            }
            GenericIO.writelnString("The coach " + (i + 1) + " has terminated.");
        }
        GenericIO.writelnString();

       // GenericIO.writelnString();
        try {
            refree.join();
        } catch (InterruptedException e) {
        }
        GenericIO.writelnString("The refree has terminated.");
        GenericIO.writelnString();

        repos.printSumUp();

    }

}
