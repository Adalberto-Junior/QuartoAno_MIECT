package sharedRegions;

import javax.swing.text.Position;

import comumInfra.MemFIFO;
import entities.Coach;
import entities.CoachStates;
import entities.Refree;
import entities.RefreeStates;
import main.SimulPar;

/**
 * Refree Site.
 *
 * It is responsible to simulate the refree area
 * and is implemented as an implicit monitor.
 * All public methods are executed in mutual exclusion.
 * 
 * 
 */

public class Refree_site {

    /**
     * Array of Integer to keep the score of the Game.
     */
    private int[] finalScore;

    /**
     * Variable to wake up the refree when the teams are ready to proceed.
     */
    private boolean infomeRefree;

    /**
     * Variable that indicates whether the trial has ended.
     */
    private boolean assertTriallDecision;

    /**
     * Variable to increment the coach and indicate the last of the 2.
     */
    private int nOfCoach;

    /**
     * Reference to the general repository.
     */

    private final GeneralRepos repos;

    /**
     * Reference to the general Contestants bench.
     */

    private Contestants_bench bench;

    /**
     * Reference to the play ground.
     */

    private final PlayGround plGrnd;

    /**
     * Refree site instantiation.
     *
     * @param repos reference to the general repository
     * @param bench reference to the Contestant bench
     * @param bench reference to the paly ground
     */

    public Refree_site(GeneralRepos repos, Contestants_bench bench, PlayGround playGround) {
        this.repos = repos;
        this.bench = bench;
        plGrnd = playGround;
        finalScore = new int[SimulPar.T];
        infomeRefree = false;
        assertTriallDecision = false;
        nOfCoach = 0;
    }

    // boolean trial_Called = false;

    // boolean wait_for_team = true;

    // private final Customer[] cust;

    /**
     * Operation callTrial.
     *
     * It is called by the refree When he start a new Trial.
     * 
     * @param NB Current Trial number;
     */
    public synchronized void callTrial(int NB) {
        repos.setTrialNumber(NB);
        int PS = plGrnd.getPositionCenterRope();
        repos.setPositionCentreRope(PS);
        Refree refree = (Refree) Thread.currentThread();
        refree.setRefreeState(RefreeStates.TEAMSREADY);
        int state = refree.getRefreeState();
        repos.setRefreeState(state);

        bench.wakeUpCoach(); // wake up the Coach after a callTrial()

        while (!infomeRefree) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * Operation declareMatchWinner.
     *
     * It is called by the refree When he finish the Match.
     * 
     */
    public synchronized void declareMatchWinner() {
        int champion = 0; // Team's champion
        Refree refree = (Refree) Thread.currentThread();
        refree.setRefreeState(RefreeStates.ENDOFTHEMATCH);
        int state = refree.getRefreeState();
        repos.setRefreeState(state);
        repos.setScore(finalScore);
        if (finalScore[0] > finalScore[1])
            champion = 1;
        else
            champion = 2;

        repos.setChampion(champion);

    }

    /**
     * Operation declareGameWinner.
     *
     * It is called by the refree When he finish the current Game.
     * 
     */
    public synchronized void declareGameWinner(int winTeam) {
        Refree refree = (Refree) Thread.currentThread();
        refree.setRefreeState(RefreeStates.ENDOFAGAME);
        int state = refree.getRefreeState();
        repos.setRefreeState(state);

        if (winTeam == 1)
            finalScore[0] += 1;
        else
            finalScore[1] += 1;
        repos.setWinTeam(winTeam);
    }

    public synchronized void infomeRefree() {
        Coach coach = (Coach) Thread.currentThread();
        coach.setCoachState(CoachStates.WATCHTRIAL);
        int coachTeamID = coach.getCoachTeamId();
        int coachState = coach.getCoachState();
        repos.setCoachState(coachTeamID, coachState);

        nOfCoach++;
        if (nOfCoach == 2) {
            infomeRefree = true;
            notifyAll();
        }

        while (!assertTriallDecision) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }

    }

    /**
     * Operation anounceNewGame.
     *
     * It is called by the refree When he start a new Game.
     * 
     * @param nOfGame Current game number;
     */
    public synchronized void anounceNewGame(int nOfGame) {
        repos.setGame(nOfGame);
        Refree refree = (Refree) Thread.currentThread();
        refree.setRefreeState(RefreeStates.STARTOFAGAME);
        int state = refree.getRefreeState();
        repos.setRefreeState(state);
    }

    /**
     * Operation assertTriallDecision().
     *
     * It is called by the refree When he finish the trial and wake up the Coach.
     * 
     */
    public synchronized void assertTriallDecision() {
        assertTriallDecision = true;
        notifyAll();
    }

}
