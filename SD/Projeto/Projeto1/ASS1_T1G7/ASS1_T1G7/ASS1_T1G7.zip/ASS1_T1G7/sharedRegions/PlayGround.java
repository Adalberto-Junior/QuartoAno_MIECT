package sharedRegions;

import main.*;
import entities.*;
import comumInfra.*;
import genclass.GenericIO;

/**
 * Play Ground.
 *
 * It is responsible to simulate the play area
 * and is implemented as an implicit monitor.
 * All public methods are executed in mutual exclusion.
 * 
 * 
 */
public class PlayGround {
    /**
     * Reference to the general repository.
     */

    private final GeneralRepos repos;

    /**
     * Varail booleans that indicates if the last contestant is done.
     */
    private boolean amDone;

    /**
     * Varail to indicate the last contestant is done.
     */
    private int totalContestant;

    /**
     * Varail booleans that indicates if the current trial is end.
     */
    private boolean assertTriallDecision;

    /**
     * Varail booleans that indicates if the trial is end and have a winnig.
     */
    private boolean trialDecision;

    /**
     * Variable that indicates whether the Match has ended.
     */
    private boolean endOfMatch;

    /**
     * Array with the strength of the contestant who was selected to play
     */
    private int[][] strength;

    /**
     * Array of Integer to keep the score of the trial.
     */
    private int[] score;

    /**
     * Position of the centre of the rope.
     */
    private int PS;

    /**
     * Varial to indicte if refree do the callTriall
     */
    private boolean callTrial;

    /**
     * Play Ground instantiation.
     *
     * @param repos reference to the general repository
     */

    public PlayGround(GeneralRepos repos) {

        this.repos = repos;
        amDone = false;
        totalContestant = 0;
        endOfMatch = false;
        trialDecision = false;
        callTrial = false;
        strength = new int[SimulPar.N][SimulPar.M - 2];
        score = new int[SimulPar.T];
        score[0] = 0;
        score[1] = 0;
        PS = 0;
    }

    /**
     * Operation Start Trial.
     *
     * It is called by the refree when he want to start the trial.
     * 
     */

    public synchronized void startTrial() {
        Refree refree = (Refree) Thread.currentThread();
        refree.setRefreeState(RefreeStates.WAITFORTRIALCONCLUSION);
        int state = refree.getRefreeState();
        repos.setRefreeState(state);
        score[0] = 0;
        score[1] = 0;
    }

    /**
     * Operation GetRead.
     *
     * It is called by the contestants When they ready to start pulling the rope.
     * 
     */

    public synchronized void getRead() {
        Contestant contestant = (Contestant) Thread.currentThread();
        int ContID = contestant.getContestantID();
        int stateCont = contestant.getContestantState();
        int contTeamId = contestant.getContestantTeamId();

        if (stateCont == ContestantStates.STANDINPOSITION) {
            contestant.setContestantState(ContestantStates.DOYOURBEST);
            int newstateCont = contestant.getContestantState();
            repos.setContestantState(contTeamId, ContID, newstateCont);
        }

    }

    /**
     * Operation Pull The Rope.
     *
     * It is called by the contestants When they ready are pulling the rope.
     * 
     * @return True when the game is end;
     */

    public synchronized boolean pullTheRope() {
        try {
            wait((long) (1 + 500 * Math.random()));
        } catch (InterruptedException e) {
        }
        // System.out.println("Acordei");
        Contestant contestant = (Contestant) Thread.currentThread();
        int ContID = contestant.getContestantID();
        int stateCont = contestant.getContestantState();
        int contTeamId = contestant.getContestantTeamId();

        if (stateCont == ContestantStates.DOYOURBEST) {
            contestant.subStreangth();
        }

        return true;
    }

    /**
     * Operation Am Done.
     *
     * It is called by the contestants When they finish the trial.
     * The last contestant will wake up the refree;
     * 
     */

    public synchronized void amDone() {
        Contestant contestant = (Contestant) Thread.currentThread();
        if (contestant.getContestantState() == ContestantStates.DOYOURBEST)
            totalContestant++;

        if (totalContestant == 6) {
            amDone = true;
            totalContestant = 0;
            notifyAll();
        }

        while (!assertTriallDecision) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }

    }

    /**
     * Operation assertTriallDecision.
     *
     * It is called by the refree When he finish the trial.
     * 
     * @return winTean The trail's winning team id;
     */
    public synchronized int assertTriallDecision() {

        int SGTeam1 = 0, SGTeam2 = 0;
        int winTeam = 0;
        trialDecision = false;

        for (int i = 0; i < SimulPar.T; i++) {
            for (int k = 0; k < (SimulPar.M - 2); k++) {
                if (i == 0)
                    SGTeam1 += strength[i][k];
                else
                    SGTeam2 += strength[i][k];
            }
        }
        if (SGTeam1 > SGTeam2) {
            score[0] += 1;
            PS--;
        } else if (SGTeam1 < SGTeam2) {
            score[1] += 1;
            PS++;
        }

        if (score[0] > 3 || score[1] > 3 || (score[0] == 3 && score[1] == 3)) {
            if (score[0] > 3)
                winTeam = 1;
            else
                winTeam = 2;
            trialDecision = true;
        }
        assertTriallDecision = true;
        notifyAll();

        return winTeam;
    }

    /**
     * Operation endOfMatch.
     *
     * is an auxiliary method that we created to update the endOfMatch
     * 
     * @param NG Number of the match(Game)
     * 
     */
    public synchronized void endOfMatch(int NG) {
        if (NG == 3)
            endOfMatch = true;
    }

    /**
     * Operation endOfMatch.
     *
     * is an auxiliary method that we created to take the endOfMatch
     * 
     * @return true if the the match end or not if it not end
     * 
     */
    public synchronized boolean getEndOfMatch() {
        while (endOfMatch != false && callTrial != false) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
        if (endOfMatch == true) {
            return true;
        } else {
            callTrial = false;
            notifyAll();
            return false;
        }
    }

    /**
     * Operation callTrial.
     *
     * is an method call by refree to wake up the coach when he make callTrial
     * 
     * 
     */
    public synchronized void callTrial() {
        callTrial = true;
        notifyAll();
    }

    /**
     * Operation declareMatchWinner.
     *
     * is an method call by refree when he make declareMatchWinner
     * 
     * 
     */

    public synchronized void declareMatchWinner() {
        endOfMatch = true;
        notifyAll();
    }

    /**
     * Operation setStrength.
     *
     * is an auxiliary method that we created to update the Strength array.
     * 
     * 
     */
    public synchronized void setStrength(int[][] strength) {
        this.strength = strength;
    }

    /**
     * getPositionCenterRope.
     *
     * is an auxiliary method that return the center Rope
     * 
     * 
     */
    public synchronized int getPositionCenterRope() {
        return this.PS;
    }

    /**
     * Operation getTrialDecision.
     *
     * is an auxiliary method we created to indicate if there is already
     * a winner and end the game if positive
     * 
     * @return true if there is already a winner and false if there is not
     */
    public synchronized boolean getTrialDecision() {
        return this.trialDecision;
    }

    /**
     * Operation timeToSleap.
     *
     * is an auxiliary method to bolck the refree after startTrial
     *
     */
    public synchronized void timeToSleap() {
        while (!amDone) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
    }

}
