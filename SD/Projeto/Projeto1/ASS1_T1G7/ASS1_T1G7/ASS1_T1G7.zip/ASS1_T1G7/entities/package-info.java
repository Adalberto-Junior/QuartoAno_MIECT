/**
 * Definition of the entities intervening in the Game of the Rope
 */

package entities;