package entities;

import sharedRegions.*;

public class Contestant extends Thread {

    /**
     * Contestant state.
     */
    private int contestantState;

    /**
     * Contestant Team ID.
     */
    private int contestantTeamId;

    /**
     * Contestant ID.
     */
    private int contestantID;

    /**
     * Contestant Strength
     */
    private int contestantSG;

    /**
     * Reference to the play ground.
     */

    private PlayGround plGrnd;

    /**
     * Reference to the contestant Bench.
     */

    private Contestants_bench bench;

    // int streangth = 0;

    boolean playing = false;

    /**
     * Instantiation of Contestant thread.
     *
     * @param name       thread name
     * @param id         contestant Id
     * @param teamId     contestant team id
     * @param strength   contestant strength
     * @param bench      reference to the contestant bench
     * @param playGround reference to the play groun
     */
    public Contestant(String name, int id, int teamId, int strength, Contestants_bench bench, PlayGround playGround) {
        super(name);
        this.contestantID = id;
        contestantTeamId = teamId;
        this.contestantSG = strength;
        this.bench = bench;
        this.plGrnd = playGround;
        contestantState = ContestantStates.SEATATTHEBENCH;
    }

    /**
     * Set Contestant state.
     *
     * @param state new Contestant state
     */

    public void setContestantState(int state) {
        contestantState = state;
    }

    /**
     * Set Contestant Team ID.
     *
     * @param teamId Contestant Team ID
     */

    public void setContestantTeamId(int teamId) {
        contestantTeamId = teamId;
    }

    /**
     * Set Contestant ID.
     *
     * @param contID Contestant ID
     */

    public void setContestantID(int contID) {
        contestantID = contID;
    }

    /**
     * Set Contestant Strength.
     *
     * @param SG Contestant Strength
     */

    public void setContestantSG(int SG) {
        contestantSG = SG;
    }

    /**
     * Set new Reference to the contestant bench.
     *
     * @param bench Contestant Strength
     */

    public void setContestantBench(Contestants_bench bench) {
        this.bench = bench;
    }

    /**
     * Get Contestant state.
     *
     * @return Contestant state
     */

    public int getContestantState() {
        return contestantState;
    }

    /**
     * Get Contestant Team Id.
     *
     * @return Contestant Team Id
     */

    public int getContestantTeamId() {
        return contestantTeamId;
    }

    /**
     * Get Contestant Id.
     *
     * @return Contestant Id
     */

    public int getContestantID() {
        return contestantID;
    }

    /**
     * Get Contestant Strength.
     *
     * @return Contestant Strength
     */

    public int getContestantSG() {
        return contestantSG;
    }

    @Override
    public void run() {

        boolean endOfMatch = false;
        boolean matchOne = true;

        while (!endOfMatch) {
            bench.followCoachAdvice();
            plGrnd.getRead();
            plGrnd.pullTheRope();
            plGrnd.amDone();
            bench.seatDown();
            endOfMatch = plGrnd.getEndOfMatch();
            matchOne = false;
        }

    }

    public void addStreangth() {

        this.contestantSG += 1;
    }

    public void subStreangth() {
        if (this.contestantSG > 6) {
            this.contestantSG -= 1;
        }
    }

}