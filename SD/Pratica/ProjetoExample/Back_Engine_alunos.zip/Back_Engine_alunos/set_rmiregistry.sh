rmiregistry -J-Djava.rmi.server.codebase="http://localhost/ruib/classes/"\
            -J-Djava.rmi.server.useCodebaseOnly=true $1
