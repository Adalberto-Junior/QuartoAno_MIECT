java -Djava.rmi.server.codebase="file:///home/ruib/test/BackEngine/dir_serverSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     serverSide.ServerComputeEngine
