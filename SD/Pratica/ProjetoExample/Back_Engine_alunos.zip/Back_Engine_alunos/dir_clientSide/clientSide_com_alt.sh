java -Djava.rmi.server.codebase="file:///home/ruib/test/BackEngine/dir_clientSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     clientSide.ComputePi $1
