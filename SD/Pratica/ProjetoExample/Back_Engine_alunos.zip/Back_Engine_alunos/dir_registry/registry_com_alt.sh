java -Djava.rmi.server.codebase="file:///home/ruib/test/BackEngine/dir_registry/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     registry.ServerRegisterRemoteObject
