/**
 *  Interfaces to remote objects.
 *
 *  Back engine application: code is moved and executed remotely in a platform supposed to be more powerful.
 *  Communication is based in Java RMI.
 */

package interfaces;
